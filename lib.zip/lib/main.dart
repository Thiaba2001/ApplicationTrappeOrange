import 'package:flutter/material.dart';
import 'package:trappe_orange/views/home/authent.dart';
import 'package:trappe_orange/views/details/details.dart';

void main() {
  runApp(const MaterialApp(home: HomeScreen()));
}
