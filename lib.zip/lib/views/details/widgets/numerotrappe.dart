import 'package:flutter/material.dart';

class NumeroTrappe extends StatefulWidget {
  const NumeroTrappe({super.key});

  @override
  NumeroTrappeSate createState() => NumeroTrappeSate();
}

class NumeroTrappeSate extends State<NumeroTrappe> {
  final GlobalKey<FormState> _cleForm = GlobalKey<FormState>();
  TextEditingController numController = TextEditingController();
  @override
  void dispose() {
    numController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
        key: _cleForm,
        child: Column(
          children: <Widget>[
            Container(
              width: 350,
              height: 75,
              decoration: BoxDecoration(
                  border: Border.all(width: 2, color: Colors.orange),
                  borderRadius: BorderRadius.circular(40)),
              child: TextFormField(
                controller: numController,
                decoration: const InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Numero de trappe',
                    hintStyle: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.black),
                    prefixIcon: Icon(
                      Icons.numbers,
                      color: Colors.orange,
                    )),
                validator: (value) {
                  if (value != null && value.isEmpty) {
                    return ('Veuilliez entrer le numero de trappe');
                  }
                  return null;
                },
              ),
            ),
            const SizedBox(
              height: 60,
              width: 60,
            ),
            Container(
              width: 300,
              height: 60,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFFFF9800),
                    Colors.black,
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(40),
              ),
              child: ElevatedButton(
                onPressed: () {},
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  elevation: 3,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(40)),
                ),
                child: const Text(
                  'Enregistrer',
                  style: TextStyle(fontSize: 20, color: Colors.white),
                ),
              ),
            ),
          ],
        ));
  }
}
