import 'package:flutter/material.dart';

class Motif extends StatefulWidget {
  const Motif({super.key});

  @override
  MotifState createState() => MotifState();
}

class MotifState extends State<Motif> {
  bool isCheked = false;

  void handleCheckbox(bool? newvalue) {
    if (newvalue != null) {
      setState(() {
        isCheked = newvalue;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 350,
      height: 75,
      child: Container(
        width: 300,
        height: 100,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.orange, width: 2),
          borderRadius: BorderRadius.circular(40),
        ),
        child:
            Row(mainAxisAlignment: MainAxisAlignment.start, children: <Widget>[
          const Icon(
            Icons.work_history_outlined,
            color: Colors.orange,
          ),
          const Text('   '),
          const Text(
            'Ouvrir Trappe',
            style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
          ),
          Checkbox(
            side: const BorderSide(width: 2),
            checkColor: Colors.white,
            fillColor:
                MaterialStateColor.resolveWith((Set<MaterialState> states) {
              if (states.contains(MaterialState.selected)) {
                return Colors
                    .orange; // Couleur de remplissage lorsque la case est cochée
              }
              return Colors.transparent;
            }),
            value: isCheked,
            onChanged: handleCheckbox,
          )
        ]),
      ),
    );
  }
}
