import 'package:flutter/material.dart';
import 'package:trappe_orange/views/details/widgets/montext.dart';
import 'package:trappe_orange/views/details/widgets/renseignement.dart';
import 'package:trappe_orange/views/details/widgets/numerotrappe.dart';

class MyDetails extends StatelessWidget {
  const MyDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.orange,
          leading: const Icon(Icons.arrow_back),
          title: const Text('Ajout Details'),
        ),
        body: Center(
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  'assets/images/chaine.jpeg',
                  width: 200,
                  height: 200,
                ),
                const SizedBox(
                  width: 20,
                  height: 20,
                ),
                const MyText(),
                const SizedBox(
                  width: 60,
                  height: 60,
                ),
                const Motif(),
                const SizedBox(
                  width: 30,
                  height: 30,
                ),
                const NumeroTrappe(),
              ]),
        ));
  }
}
