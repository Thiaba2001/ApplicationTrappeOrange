import 'package:flutter/material.dart';
import 'package:trappe_orange/widgets/formulaire.dart';
import 'package:trappe_orange/views/details/details.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 246, 144, 12),
        leading: const Icon(Icons.person),
        title: const Text('Page Authentification '),
        actions: const <Widget>[
          Icon(Icons.more_vert),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Image.asset(
              'assets/images/chaine.jpeg',
              width: 200,
              height: 200,
            ),
            const SizedBox(
              width: 5,
              height: 5,
            ),
            const Text(
              'Trappe ',
              style: TextStyle(
                fontSize: 70,
                fontWeight: FontWeight.w900,
                color: Colors.black,
              ),
            ),
            const Text(
              'Orange',
              style: TextStyle(
                  fontSize: 70,
                  fontWeight: FontWeight.w900,
                  color: Colors.orange,
                  height: 0.8),
            ),
            const SizedBox(
              height: 30,
              width: 30,
            ),
            const Padding(
              padding: EdgeInsets.only(left: 10),
              child: Text(
                'Welcome to',
                style: TextStyle(
                    fontSize: 25, fontWeight: FontWeight.bold, height: 1),
              ),
            ),
            Image.asset(
              'assets/images/chaine2.PNG',
              width: 500,
              height: 20,
            ),
            const SizedBox(
              height: 25,
            ),
            Align(
              alignment: Alignment.topCenter,
              child: LoginForm(
                onAuthenticationSuccess: (bool isAuthenticated) {
                  if (isAuthenticated) {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const MyDetails()));
                  }
                },
              ),
            ),
            const SizedBox(
              width: 20,
              height: 20,
            ),
            const Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Text(
                  'motdepasse oublier?',
                  style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.black),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
