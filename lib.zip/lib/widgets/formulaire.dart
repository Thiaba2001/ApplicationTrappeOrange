import 'package:flutter/material.dart';
import 'package:trappe_orange/service/authetification.dart';

class LoginForm extends StatefulWidget {
  final Function(bool) onAuthenticationSuccess;

  const LoginForm({Key? key, required this.onAuthenticationSuccess})
      : super(key: key);
  @override
  LoginFormState createState() => LoginFormState();
}

class LoginFormState extends State<LoginForm> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController loginController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  bool isAuthenticated = false;
  void authenticateAndCallback() async {
    final login = loginController.text;
    final password = passwordController.text;
    final isUserAuthenticated = await AuthService.authenticate(login, password);

    if (isUserAuthenticated) {
      widget.onAuthenticationSuccess(true);
    }
  }

  @override
  void dispose() {
    loginController.dispose();
    passwordController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(children: <Widget>[
        Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.orange, width: 2),
              borderRadius: BorderRadius.circular(30)),
          width: 350,
          height: 70,
          child: TextFormField(
            controller: loginController,
            decoration: const InputDecoration(
              hintStyle: TextStyle(
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                  fontSize: 20),
              hintText: 'Login',
              prefixIcon: Icon(Icons.login),
              border: InputBorder.none,
            ),
            validator: (value) {
              if (value != null && value.isEmpty) {
                return ('Veuillez entrer votre login');
              }
              return null;
            },
          ),
        ),
        const SizedBox(
          width: 40,
          height: 40,
        ),
        Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.orange, width: 2),
              borderRadius: BorderRadius.circular(30)),
          width: 350,
          height: 70,
          child: TextFormField(
            controller: passwordController,
            decoration: const InputDecoration(
              hintText: 'mot de passe',
              hintStyle: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: Colors.black),
              prefixIcon: Icon(Icons.password),
              border: InputBorder.none,
            ),
            validator: (value) {
              if (value != null && value.isEmpty) {
                return ('Veuillez entrer votre mot de passe');
              }
              return null;
            },
          ),
        ),
        const SizedBox(
          width: 20,
          height: 30,
        ),
        Container(
          width: 300,
          height: 60,
          decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFFFF9800),
                  Colors.black,
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(30)),
          child: ElevatedButton(
            onPressed: isAuthenticated ? null : authenticateAndCallback,
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              elevation: 0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30)),
            ),
            child: const Text(
              "S'authentifier",
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 20,
                  fontWeight: FontWeight.bold),
            ),
          ),
        ),
      ]),
    );
  }
}
