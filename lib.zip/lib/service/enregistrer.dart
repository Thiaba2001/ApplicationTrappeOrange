import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class DetailsService {
  static Future<bool> enregistrerDetails(String technicienId,
      String motifIntervention, String numeroTrappe) async {
    final response = await http.put(
      Uri.parse('http://10.0.2.2:400/api/techniciens/$technicienId/details'),
      body: {
        'motifIntervention': motifIntervention,
        'numeroTrappe': numeroTrappe
      },
    );
    if (response.statusCode == 200) {
      return true;
    } else {
      return false;
    }

  }

}

Future<void> enregistrerDetailsTechnicien(
  String technicienId, String motifIntervention, String numeroTrappe
)async{
  final enregistrementReussi = await DetailsService.enregistrerDetails(
    technicienId,
    motifIntervention,
    numeroTrappe
  );
  if(enregistrementReussi){
    showDialog(
      context: context, 
      builder: (BuildContext context){
        return AlertDialog(
          title: Text('Succès'),
          content: Text('Les détails on été enregistrer avec succès'),
          actions: <Widget>[
            TextButton(
              onPressed: (){
                Navigator.of(context).pop();
              },
              child: const Text('Fermer'),
            ),
          ],
        );

      });
  }else{
    showDialog(
      context: context,
      builder: (BuildContext context){
        return AlertDialog(
          title:  Text('Erreur'),
          content: Text('Erreur lors de l\'enregistrer des détails'),
          actions: <Widget>[
            TextButton(
              onPressed: (){
                Navigator.of(context).pop();

              }, 
              child: Text('Fermer'),)
          ]
        )

      }
    )
  }
}
