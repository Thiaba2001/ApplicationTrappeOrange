import 'package:http/http.dart' as http;

class AuthService {
  static Future<bool> authenticate(String login, String password) async {
    final response = await http
        .post(Uri.parse('http://10.0.2.2:4000/api/authenticate'), body: {
      'login': login,
      'motdepasse': password,
    });

    if (response.statusCode == 200) {
      return true;
    } else {
      return false;
    }
  }
}
